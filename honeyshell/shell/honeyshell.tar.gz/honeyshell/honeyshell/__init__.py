"""honeyshell — an asyncssh/asyncio SSH shell honeypot core.

Design lineage: architecturally inspired by Cowrie's shell design
(command registry + base-command contract + virtual filesystem), but
re-implemented on top of asyncssh/asyncio rather than Twisted.
"""

__version__ = "0.0.1"
