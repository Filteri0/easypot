"""Concrete command implementations.

Each module here registers commands via ``@register`` and is imported by
``registry.discover()``. Split by theme as the set grows (coreutils, net, pkg,
...); for now a single ``basic`` module holds the starter set.
"""
